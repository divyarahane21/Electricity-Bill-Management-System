<?php
session_start();
include "db.php";

if(isset($_POST['login']))
{
    $mobile = $_POST['mobile'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM customers
            WHERE mobile='$mobile'
            AND password='$password'";

    $result = mysqli_query($conn,$sql);

    if(mysqli_num_rows($result)==1)
    {
        $row = mysqli_fetch_assoc($result);

        $_SESSION['customer_id']=$row['customer_id'];
        $_SESSION['customer_name']=$row['customer_name'];

        header("Location:user_dashboard.php");
    }
    else
    {
        echo "<script>alert('Invalid Mobile Number or Password');</script>";
    }
}
?>

<!DOCTYPE html>
<html>

<head>

<title>User Login</title>

<link rel="stylesheet" href="style.css">

</head>

<body>

<div class="container">

<h2 style="text-align:center;">Customer Login</h2>

<form method="POST">

<label>Mobile Number</label>

<input type="text"
name="mobile"
required>

<label>Password</label>

<input type="password"
name="password"
required>

<button
type="submit"
name="login">

Login

</button>

</form>

</div>

</body>

</html>