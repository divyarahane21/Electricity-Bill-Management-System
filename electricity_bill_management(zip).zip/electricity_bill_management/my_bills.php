<?php
session_start();

if(!isset($_SESSION['customer_id']))
{
    header("Location:user_login.php");
    exit();
}

include "db.php";
include "header.php";

$customer_id = $_SESSION['customer_id'];

$query = "SELECT * FROM bills
          WHERE customer_id='$customer_id'
          ORDER BY bill_id DESC";

$result = mysqli_query($conn,$query);
?>

<h2>My Bills</h2>

<table>

<tr>
<th>Bill ID</th>
<th>Meter No</th>
<th>Billing Month</th>
<th>Units</th>
<th>Total Amount</th>
<th>Status</th>
<th>Action</th>
</tr>

<?php

if(mysqli_num_rows($result)>0)
{
while($row=mysqli_fetch_assoc($result))
{
?>

<tr>

<td><?php echo $row['bill_id']; ?></td>

<td><?php echo $row['meter_number']; ?></td>

<td><?php echo $row['billing_month']; ?></td>

<td><?php echo $row['units']; ?></td>

<td>₹ <?php echo $row['total_amount']; ?></td>

<td><?php echo $row['payment_status']; ?></td>

<td>

<?php

if($row['payment_status']=="Unpaid")
{
?>

<a href="pay_bill.php?id=<?php echo $row['bill_id']; ?>">
<button>Pay Now</button>
</a>

<?php
}
else
{
echo "<b style='color:green;'>Paid ✓</b>";
}
?>

</td>

</tr>

<?php
}
}
else
{
?>

<tr>
<td colspan="7">No Bills Found</td>
</tr>

<?php
}
?>

</table>

<?php
include "footer.php";
?>