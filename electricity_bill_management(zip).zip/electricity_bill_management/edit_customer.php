<?php
include "db.php";
include "header.php";

// Check ID
if(!isset($_GET['id']))
{
    header("Location: view_customers.php");
    exit();
}

$id = $_GET['id'];

// Fetch Customer Data
$result = mysqli_query($conn, "SELECT * FROM customers WHERE customer_id='$id'");
$row = mysqli_fetch_assoc($result);

// Update Customer
if(isset($_POST['update']))
{
    $name = $_POST['customer_name'];
    $mobile = $_POST['mobile'];
    $email = $_POST['email'];
    $address = $_POST['address'];

    $sql = "UPDATE customers
            SET customer_name='$name',
                mobile='$mobile',
                email='$email',
                address='$address'
            WHERE customer_id='$id'";

    if(mysqli_query($conn, $sql))
    {
        echo "<script>alert('Customer Updated Successfully');</script>";
        echo "<script>window.location='view_customers.php';</script>";
    }
    else
    {
        echo "<script>alert('Update Failed');</script>";
    }
}
?>

<h2>Edit Customer</h2>

<form method="POST">

    <label>Customer Name</label>
    <input type="text" name="customer_name"
        value="<?php echo $row['customer_name']; ?>" required>

    <label>Mobile</label>
    <input type="text" name="mobile"
        value="<?php echo $row['mobile']; ?>" required>

    <label>Email</label>
    <input type="email" name="email"
        value="<?php echo $row['email']; ?>">

    <label>Address</label>
    <textarea name="address" rows="4"><?php echo $row['address']; ?></textarea>

    <button type="submit" name="update">Update Customer</button>

</form>

<?php
include "footer.php";
?>