</div>

<footer>

<p>© 2026 Electricity Bill Management System | Developed by Divya Rahane</p>

</footer>

</body>
</html>