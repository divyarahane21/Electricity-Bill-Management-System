<?php
include "db.php";

// Check if ID is provided
if(isset($_GET['id']))
{
    $id = $_GET['id'];

    // Delete Customer
    $sql = "DELETE FROM customers WHERE customer_id='$id'";

    if(mysqli_query($conn, $sql))
    {
        echo "<script>alert('Customer Deleted Successfully');</script>";
    }
    else
    {
        echo "<script>alert('Unable to Delete Customer');</script>";
    }
}
else
{
    echo "<script>alert('Invalid Request');</script>";
}

header("Location: view_customers.php");
exit();
?>