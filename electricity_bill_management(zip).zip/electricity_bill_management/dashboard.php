<?php
session_start();

if(!isset($_SESSION['admin']))
{
    header("Location: admin_login.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Admin Dashboard</title>

<style>
body{
    margin:0;
    font-family:Arial;
    background:#f1f5f9;
}

/* HEADER */
.header{
    background:linear-gradient(135deg,#1e3a8a,#0f172a);
    color:white;
    padding:15px 20px;
    text-align:center;
}

.header h2{
    margin:0;
}

/* CONTAINER */
.container{
    padding:30px;
}

/* CARDS */
.cards{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(220px,1fr));
    gap:20px;
    margin-top:20px;
}

.card{
    background:white;
    padding:25px;
    border-radius:12px;
    box-shadow:0px 5px 15px rgba(0,0,0,0.1);
    text-align:center;
    transition:0.3s;
}

.card:hover{
    transform:translateY(-5px);
    box-shadow:0px 10px 20px rgba(0,0,0,0.2);
}

.card h3{
    color:#1e3a8a;
    margin-bottom:15px;
}

.card a{
    text-decoration:none;
}

.btn{
    padding:10px 15px;
    border:none;
    background:#1e3a8a;
    color:white;
    border-radius:8px;
    cursor:pointer;
    transition:0.3s;
}

.btn:hover{
    background:#0f172a;
}

/* WELCOME BOX */
.welcome{
    background:white;
    padding:20px;
    border-radius:12px;
    box-shadow:0px 5px 15px rgba(0,0,0,0.1);
    margin-top:20px;
}

.logout{
    text-align:right;
    margin-top:10px;
}

.logout a{
    color:red;
    text-decoration:none;
    font-weight:bold;
}
</style>

</head>

<body>

<div class="header">
    <h2>Electricity Bill Management System</h2>
</div>

<div class="container">

<div class="welcome">
    <h2>Welcome Admin 👨‍💼</h2>
    <p>You are logged into the admin dashboard.</p>

    <div class="logout">
        <a href="logout.php">Logout</a>
    </div>
</div>

<div class="cards">

<div class="card">
    <h3>Customers</h3>
    <a href="view_customers.php">
        <button class="btn">View</button>
    </a>
</div>

<div class="card">
    <h3>Add Customer</h3>
    <a href="add_customer.php">
        <button class="btn">Add</button>
    </a>
</div>

<div class="card">
    <h3>Generate Bill</h3>
    <a href="generate_bill.php">
        <button class="btn">Create</button>
    </a>
</div>

<div class="card">
    <h3>Bill History</h3>
    <a href="bill_history.php">
        <button class="btn">Open</button>
    </a>
</div>

</div>

</div>

</body>
</html>