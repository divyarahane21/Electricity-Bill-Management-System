<?php
session_start();

if(!isset($_SESSION['customer_id']))
{
    header("Location:user_login.php");
    exit();
}

include "db.php";

$customer_id = $_SESSION['customer_id'];

// Get user info
$user = mysqli_fetch_assoc(mysqli_query($conn,
"SELECT * FROM customers WHERE customer_id='$customer_id'"));

// Bills count
$total = mysqli_num_rows(mysqli_query($conn,
"SELECT * FROM bills WHERE customer_id='$customer_id'"));

$pending = mysqli_num_rows(mysqli_query($conn,
"SELECT * FROM bills WHERE customer_id='$customer_id' AND payment_status='Unpaid'"));

$paid = mysqli_num_rows(mysqli_query($conn,
"SELECT * FROM bills WHERE customer_id='$customer_id' AND payment_status='Paid'"));
?>

<!DOCTYPE html>
<html>
<head>
<title>User Dashboard</title>

<style>
body{
    margin:0;
    font-family:Arial;
    background:#f1f5f9;
}

.header{
    background:linear-gradient(135deg,#0f172a,#1e3a8a);
    color:white;
    padding:15px;
    text-align:center;
}

.container{
    padding:25px;
}

/* PROFILE CARD */
.profile{
    background:white;
    padding:20px;
    border-radius:12px;
    box-shadow:0px 5px 15px rgba(0,0,0,0.1);
}

.profile h2{
    margin:0;
    color:#1e3a8a;
}

/* CARDS */
.cards{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(200px,1fr));
    gap:15px;
    margin-top:20px;
}

.card{
    background:white;
    padding:20px;
    border-radius:10px;
    text-align:center;
    box-shadow:0px 5px 15px rgba(0,0,0,0.1);
}

.card h3{
    color:#1e3a8a;
}

/* BUTTONS */
.btn{
    margin-top:10px;
    padding:10px;
    border:none;
    background:#1e3a8a;
    color:white;
    border-radius:8px;
    cursor:pointer;
    text-decoration:none;
    display:inline-block;
}

.btn:hover{
    background:#0f172a;
}

/* INFO */
.info{
    margin-top:10px;
    color:#555;
    font-size:14px;
}
</style>

</head>

<body>

<div class="header">
    <h2>User Dashboard</h2>
</div>

<div class="container">

<!-- USER INFO -->
<div class="profile">

<h2>Welcome, <?php echo $user['customer_name']; ?> 👤</h2>

<div class="info">
<p><b>Mobile:</b> <?php echo $user['mobile']; ?></p>
<p><b>Email:</b> <?php echo $user['email']; ?></p>
<p><b>Address:</b> <?php echo $user['address']; ?></p>
</div>

</div>

<!-- STATS -->
<div class="cards">

<div class="card">
<h3>Total Bills</h3>
<p><?php echo $total; ?></p>
</div>

<div class="card">
<h3>Pending Bills</h3>
<p><?php echo $pending; ?></p>
</div>

<div class="card">
<h3>Paid Bills</h3>
<p><?php echo $paid; ?></p>
</div>

</div>

<!-- ACTION -->
<div class="cards">

<div class="card">
<h3>My Bills</h3>
<a class="btn" href="my_bills.php">View Bills</a>
</div>

<div class="card">
<h3>Logout</h3>
<a class="btn" href="user_logout.php">Exit</a>
</div>

</div>

</div>

</body>
</html>