<?php
include "db.php";
include "header.php";

if(isset($_POST['generate']))
{
    $customer_id = $_POST['customer_id'];
    $meter_number = $_POST['meter_number'];
    $billing_month = $_POST['billing_month'];
    $previous_reading = $_POST['previous_reading'];
    $current_reading = $_POST['current_reading'];
    $rate = $_POST['rate'];

    $units = $current_reading - $previous_reading;

    if($units < 0)
    {
        echo "<script>alert('Current Reading must be greater than Previous Reading');</script>";
    }
    else
    {
        $total_amount = $units * $rate;
        $bill_date = date("Y-m-d");

        $sql = "INSERT INTO bills
        (customer_id,meter_number,billing_month,previous_reading,current_reading,units,rate,total_amount,bill_date)
        VALUES
        ('$customer_id','$meter_number','$billing_month','$previous_reading','$current_reading','$units','$rate','$total_amount','$bill_date')";

        if(mysqli_query($conn,$sql))
        {
            echo "<script>alert('Bill Generated Successfully');</script>";
            echo "<script>window.location='bill_history.php';</script>";
        }
        else
        {
            echo "<script>alert('Error Generating Bill');</script>";
        }
    }
}
?>

<h2>Generate Electricity Bill</h2>

<form method="POST">

<label>Select Customer</label>
<select name="customer_id" required>

<option value="">-- Select Customer --</option>

<?php
$result = mysqli_query($conn,"SELECT * FROM customers");

while($row=mysqli_fetch_assoc($result))
{
?>
<option value="<?php echo $row['customer_id']; ?>">
<?php echo $row['customer_name']; ?>
</option>
<?php
}
?>

</select>

<label>Meter Number</label>
<input type="text" name="meter_number" required>

<label>Billing Month</label>
<input type="text" name="billing_month" placeholder="July 2026" required>

<label>Previous Reading</label>
<input type="number" name="previous_reading" required>

<label>Current Reading</label>
<input type="number" name="current_reading" required>

<label>Rate Per Unit (₹)</label>
<input type="number" step="0.01" name="rate" value="8" required>

<button type="submit" name="generate">
Generate Bill
</button>

</form>

<?php
include "footer.php";
?>