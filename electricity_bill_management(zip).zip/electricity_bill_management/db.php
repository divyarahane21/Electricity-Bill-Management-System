<?php

$host="localhost";
$user="root";
$password="shubhangi@19";
$database="electricity_bill";

$conn=mysqli_connect($host,$user,$password,$database);

if(!$conn)
{
    die("Database Connection Failed : ".mysqli_connect_error());
}

?>